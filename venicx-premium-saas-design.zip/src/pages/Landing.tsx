import { Navbar } from "../components/layout/Navbar";
import { Footer } from "../components/layout/Footer";
import { Hero } from "../components/marketing/Hero";
import { ProcessSteps } from "../components/marketing/ProcessSteps";
import { Features } from "../components/marketing/Features";
import { Testimonials } from "../components/marketing/Testimonials";
import { Pricing } from "../components/marketing/Pricing";
import { FAQ } from "../components/marketing/FAQ";
import { FinalCTA } from "../components/marketing/FinalCTA";

export function Landing() {
  return (
    <div className="min-h-screen bg-ink">
      <Navbar />
      <main>
        <Hero />
        <ProcessSteps />
        <Features />
        <Testimonials />
        <Pricing />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
