import { DashboardShell } from "../components/dashboard/DashboardShell";
import { KpiGrid } from "../components/dashboard/KpiGrid";
import { ChartsPanel } from "../components/dashboard/ChartsPanel";
import { LeadsPanel } from "../components/dashboard/LeadsPanel";

export function Dashboard() {
  return (
    <DashboardShell>
      <div className="mb-6 lg:hidden">
        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-2">
          Overview
        </p>
        <h1 className="text-2xl font-bold tracking-tight text-white">
          Welcome back
        </h1>
      </div>

      <div className="space-y-4 md:space-y-6">
        <KpiGrid />
        <ChartsPanel />
        <LeadsPanel />
      </div>
    </DashboardShell>
  );
}
