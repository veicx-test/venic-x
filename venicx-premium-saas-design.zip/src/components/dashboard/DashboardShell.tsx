import { ReactNode, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Bell,
  CalendarCheck2,
  LayoutDashboard,
  Menu,
  Settings,
  Users,
  X,
  FileBarChart2,
  LogOut,
} from "lucide-react";
import { cn } from "../../utils/cn";

const NAV_ITEMS = [
  { label: "Overview", icon: LayoutDashboard, active: true },
  { label: "Leads", icon: Users, active: false },
  { label: "Appointments", icon: CalendarCheck2, active: false },
  { label: "Reports", icon: FileBarChart2, active: false },
  { label: "Settings", icon: Settings, active: false },
];

export function DashboardShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="min-h-screen bg-ink lg:flex">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-white/[0.08] bg-ink-soft lg:flex">
        <div className="flex h-20 items-center px-7">
          <Link to="/" className="text-lg font-extrabold tracking-tight text-white">
            VENIC<span className="text-lime">X</span>
          </Link>
        </div>
        <nav className="flex-1 px-4 py-4">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.label}
              className={cn(
                "mb-1 flex h-11 w-full items-center gap-3 rounded-xl px-3.5 text-[14px] font-medium transition-colors",
                item.active
                  ? "bg-lime/10 text-lime"
                  : "text-muted hover:bg-white/[0.05] hover:text-white"
              )}
            >
              <item.icon className="h-[18px] w-[18px]" strokeWidth={1.9} />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="border-t border-white/[0.08] p-4">
          <div className="flex items-center gap-3 rounded-xl px-3 py-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-lime/15 text-sm font-bold text-lime">
              VX
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-white">
                Demo Business
              </p>
              <p className="truncate text-xs text-muted-2">Owner account</p>
            </div>
            <Link to="/" aria-label="Log out">
              <LogOut className="h-4 w-4 text-muted-2" />
            </Link>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-white/[0.08] bg-ink/90 px-4 backdrop-blur lg:hidden">
        <Link to="/" className="text-lg font-extrabold tracking-tight text-white">
          VENIC<span className="text-lime">X</span>
        </Link>
        <div className="flex items-center gap-2">
          <button className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white">
            <Bell className="h-[18px] w-[18px]" />
          </button>
          <button
            onClick={() => setOpen(true)}
            aria-label="Open menu"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Mobile nav overlay */}
      <div
        className={cn(
          "fixed inset-0 z-50 bg-ink transition-opacity duration-300 lg:hidden",
          open ? "opacity-100" : "pointer-events-none opacity-0"
        )}
      >
        <div className="flex h-16 items-center justify-between px-4">
          <span className="text-lg font-extrabold tracking-tight text-white">
            VENIC<span className="text-lime">X</span>
          </span>
          <button
            onClick={() => setOpen(false)}
            aria-label="Close menu"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <nav className="px-4 py-2">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.label}
              onClick={() => setOpen(false)}
              className={cn(
                "mb-2 flex h-14 w-full items-center gap-3 rounded-xl px-4 text-base font-semibold",
                item.active
                  ? "bg-lime/10 text-lime"
                  : "text-white/85 hover:bg-white/[0.05]"
              )}
            >
              <item.icon className="h-5 w-5" strokeWidth={1.9} />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="mt-4 border-t border-white/[0.08] px-4 pt-4">
          <Link
            to="/"
            className="flex h-14 items-center justify-center gap-2 rounded-xl border border-white/15 text-base font-semibold text-white"
          >
            <LogOut className="h-4 w-4" />
            Back to website
          </Link>
        </div>
      </div>

      {/* Main content */}
      <div className="min-w-0 flex-1">
        <div className="hidden h-20 items-center justify-between border-b border-white/[0.08] px-8 lg:flex">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-2">
              Overview
            </p>
            <h1 className="text-xl font-bold tracking-tight text-white">
              Welcome back
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 text-white transition-colors hover:border-white/25">
              <Bell className="h-[18px] w-[18px]" />
            </button>
          </div>
        </div>
        <div className="container-px py-6 md:py-8 lg:px-8">{children}</div>
      </div>
    </div>
  );
}
