import { TrendingUp } from "lucide-react";
import { KPIS } from "./data";
import { useCountUp } from "../../lib/hooks";

function KpiCard({
  label,
  value,
  suffix,
  change,
}: {
  label: string;
  value: number;
  suffix: string;
  change: string;
}) {
  const animated = useCountUp(value, true, 1200);
  const display =
    suffix === "%" ? animated.toFixed(1) : Math.round(animated).toLocaleString();

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-surface/60 p-5 md:p-6">
      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-2">
        {label}
      </p>
      <div className="mt-3 flex items-end justify-between gap-2">
        <p className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
          {display}
          {suffix}
        </p>
        <span className="mb-1 flex items-center gap-1 text-xs font-semibold text-lime">
          <TrendingUp className="h-3.5 w-3.5" />
          {change}
        </span>
      </div>
    </div>
  );
}

export function KpiGrid() {
  return (
    <div className="grid grid-cols-2 gap-3 md:gap-4 lg:grid-cols-4">
      {KPIS.map((kpi) => (
        <KpiCard key={kpi.label} {...kpi} />
      ))}
    </div>
  );
}
