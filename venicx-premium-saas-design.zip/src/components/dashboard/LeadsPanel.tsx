import { useMemo, useState } from "react";
import { Search, Flame, Sun, Snowflake, Phone } from "lucide-react";
import { LEADS, Lead, LeadStatus } from "./data";
import { StatusBadge } from "../ui";
import { cn } from "../../utils/cn";

const FILTERS: { label: string; value: LeadStatus | "all" }[] = [
  { label: "All", value: "all" },
  { label: "Hot", value: "hot" },
  { label: "Warm", value: "warm" },
  { label: "Cold", value: "cold" },
];

function statusIcon(status: LeadStatus) {
  if (status === "hot") return <Flame className="h-3.5 w-3.5" />;
  if (status === "warm") return <Sun className="h-3.5 w-3.5" />;
  return <Snowflake className="h-3.5 w-3.5" />;
}

function LeadCard({ lead }: { lead: Lead }) {
  return (
    <div className="rounded-2xl border border-white/[0.08] bg-surface/60 p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[15px] font-bold text-white">
            {lead.business}
          </p>
          <p className="mt-0.5 text-xs text-muted-2">{lead.id}</p>
        </div>
        <StatusBadge status={lead.status} />
      </div>

      <div className="mt-4 grid grid-cols-2 gap-y-3 text-sm">
        <div>
          <p className="text-[10px] uppercase tracking-wider text-muted-2">
            Contact
          </p>
          <p className="mt-0.5 text-white/85">{lead.contact}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider text-muted-2">
            Source
          </p>
          <p className="mt-0.5 text-white/85">{lead.source}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider text-muted-2">
            Service
          </p>
          <p className="mt-0.5 text-white/85">{lead.service}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider text-muted-2">
            Score
          </p>
          <p className="mt-0.5 font-semibold text-lime">{lead.score}</p>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-white/[0.06] pt-4">
        <div>
          <p className="text-xs text-muted-2">{lead.stage} · {lead.lastActivity}</p>
        </div>
        <button className="flex h-9 items-center gap-1.5 rounded-full bg-white/[0.06] px-3 text-xs font-semibold text-white">
          <Phone className="h-3.5 w-3.5" />
          Contact
        </button>
      </div>
    </div>
  );
}

export function LeadsPanel() {
  const [filter, setFilter] = useState<LeadStatus | "all">("all");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    return LEADS.filter((lead) => {
      const matchesFilter = filter === "all" || lead.status === filter;
      const matchesQuery = lead.business
        .toLowerCase()
        .includes(query.toLowerCase());
      return matchesFilter && matchesQuery;
    });
  }, [filter, query]);

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-surface/40">
      <div className="flex flex-col gap-4 border-b border-white/[0.08] p-5 sm:flex-row sm:items-center sm:justify-between md:p-6">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-2">
            Lead management
          </p>
          <p className="mt-1 text-lg font-bold text-white">Recent leads</p>
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-2" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search business..."
              className="h-11 w-full rounded-full border border-white/10 bg-white/[0.04] pl-10 pr-4 text-sm text-white placeholder:text-muted-2 focus:border-lime/50 sm:w-56"
            />
          </div>
          <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
            {FILTERS.map((f) => (
              <button
                key={f.value}
                onClick={() => setFilter(f.value)}
                className={cn(
                  "flex h-11 shrink-0 items-center gap-1.5 rounded-full border px-4 text-sm font-medium transition-colors",
                  filter === f.value
                    ? "border-lime/40 bg-lime/10 text-lime"
                    : "border-white/10 text-muted hover:text-white"
                )}
              >
                {f.value !== "all" && statusIcon(f.value)}
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Mobile: cards */}
      <div className="grid grid-cols-1 gap-3 p-4 md:hidden">
        {filtered.map((lead) => (
          <LeadCard key={lead.id} lead={lead} />
        ))}
        {filtered.length === 0 && (
          <p className="py-10 text-center text-sm text-muted-2">
            No leads match this filter.
          </p>
        )}
      </div>

      {/* Desktop: table */}
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full min-w-[900px] border-collapse text-left text-sm">
          <thead>
            <tr className="border-b border-white/[0.08] text-[11px] uppercase tracking-wider text-muted-2">
              <th className="px-6 py-4 font-semibold">Business</th>
              <th className="px-4 py-4 font-semibold">Source</th>
              <th className="px-4 py-4 font-semibold">Service</th>
              <th className="px-4 py-4 font-semibold">Score</th>
              <th className="px-4 py-4 font-semibold">Status</th>
              <th className="px-4 py-4 font-semibold">Stage</th>
              <th className="px-4 py-4 font-semibold">Appointment</th>
              <th className="px-6 py-4 font-semibold">Last Activity</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((lead) => (
              <tr
                key={lead.id}
                className="border-b border-white/[0.05] transition-colors hover:bg-white/[0.03]"
              >
                <td className="px-6 py-4">
                  <p className="font-semibold text-white">{lead.business}</p>
                  <p className="text-xs text-muted-2">{lead.contact}</p>
                </td>
                <td className="px-4 py-4 text-white/80">{lead.source}</td>
                <td className="px-4 py-4 text-white/80">{lead.service}</td>
                <td className="px-4 py-4 font-semibold text-lime">
                  {lead.score}
                </td>
                <td className="px-4 py-4">
                  <StatusBadge status={lead.status} />
                </td>
                <td className="px-4 py-4 text-white/80">{lead.stage}</td>
                <td className="px-4 py-4 text-white/80">{lead.appointment}</td>
                <td className="px-6 py-4 text-muted-2">{lead.lastActivity}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <p className="py-10 text-center text-sm text-muted-2">
            No leads match this filter.
          </p>
        )}
      </div>
    </div>
  );
}
