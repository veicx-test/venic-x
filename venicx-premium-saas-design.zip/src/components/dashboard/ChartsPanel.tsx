import { SOURCES, TREND } from "./data";

function TrendChart() {
  const max = Math.max(...TREND);
  const min = Math.min(...TREND);
  const width = 100;
  const height = 100;

  const points = TREND.map((v, i) => {
    const x = (i / (TREND.length - 1)) * width;
    const y = height - ((v - min) / (max - min || 1)) * height;
    return `${x},${y}`;
  }).join(" ");

  const areaPoints = `0,${height} ${points} ${width},${height}`;

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-surface/60 p-5 md:p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-2">
            Leads trend
          </p>
          <p className="mt-1 text-lg font-bold text-white">Last 12 weeks</p>
        </div>
        <span className="rounded-full bg-lime/10 px-2.5 py-1 text-xs font-semibold text-lime">
          +142%
        </span>
      </div>
      <div className="mt-6 h-40 w-full">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          preserveAspectRatio="none"
          className="h-full w-full overflow-visible"
        >
          <defs>
            <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#D6FF00" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#D6FF00" stopOpacity="0" />
            </linearGradient>
          </defs>
          <polygon points={areaPoints} fill="url(#trendFill)" />
          <polyline
            points={points}
            fill="none"
            stroke="#D6FF00"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            vectorEffect="non-scaling-stroke"
          />
        </svg>
      </div>
    </div>
  );
}

function SourceBars() {
  const max = Math.max(...SOURCES.map((s) => s.value));

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-surface/60 p-5 md:p-6">
      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-2">
        Leads by source
      </p>
      <p className="mt-1 text-lg font-bold text-white">Where leads come from</p>

      <div className="mt-6 space-y-4">
        {SOURCES.map((s) => (
          <div key={s.label}>
            <div className="mb-1.5 flex items-center justify-between text-xs">
              <span className="font-medium text-white/85">{s.label}</span>
              <span className="text-muted-2">{s.value}</span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-white/[0.06]">
              <div
                className="h-full rounded-full bg-lime transition-all duration-700"
                style={{ width: `${(s.value / max) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ChartsPanel() {
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <TrendChart />
      <SourceBars />
    </div>
  );
}
