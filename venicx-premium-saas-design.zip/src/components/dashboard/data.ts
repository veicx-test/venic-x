export type LeadStatus = "hot" | "warm" | "cold";

export type Lead = {
  id: string;
  business: string;
  contact: string;
  source: string;
  service: string;
  score: number;
  status: LeadStatus;
  stage: "New" | "Contacted" | "Booked" | "Won";
  lastActivity: string;
  appointment: "Scheduled" | "Pending" | "None";
};

export const LEADS: Lead[] = [
  {
    id: "L-1042",
    business: "Coastal Realty Group",
    contact: "S. Adams",
    source: "Website Audit",
    service: "Property Listing",
    score: 92,
    status: "hot",
    stage: "Booked",
    lastActivity: "12 min ago",
    appointment: "Scheduled",
  },
  {
    id: "L-1041",
    business: "Bright Smile Dental",
    contact: "T. Khumalo",
    source: "Google Search",
    service: "Consultation",
    score: 87,
    status: "hot",
    stage: "Contacted",
    lastActivity: "38 min ago",
    appointment: "Pending",
  },
  {
    id: "L-1040",
    business: "Naidoo Plumbing",
    contact: "R. Naidoo",
    source: "Referral",
    service: "Emergency Callout",
    score: 74,
    status: "warm",
    stage: "New",
    lastActivity: "1 hr ago",
    appointment: "None",
  },
  {
    id: "L-1039",
    business: "Kalahari Fitness Studio",
    contact: "M. van Wyk",
    source: "Instagram",
    service: "Membership",
    score: 61,
    status: "warm",
    stage: "Contacted",
    lastActivity: "2 hrs ago",
    appointment: "None",
  },
  {
    id: "L-1038",
    business: "Sunrise Auto Repairs",
    contact: "D. Botha",
    source: "Website Audit",
    service: "Service Booking",
    score: 45,
    status: "cold",
    stage: "New",
    lastActivity: "5 hrs ago",
    appointment: "None",
  },
  {
    id: "L-1037",
    business: "Green Leaf Landscaping",
    contact: "P. Dlamini",
    source: "Google Maps",
    service: "Quote Request",
    score: 38,
    status: "cold",
    stage: "New",
    lastActivity: "1 day ago",
    appointment: "None",
  },
  {
    id: "L-1036",
    business: "Harbor View Cafe",
    contact: "L. Pretorius",
    source: "Referral",
    service: "Catering Enquiry",
    score: 82,
    status: "hot",
    stage: "Won",
    lastActivity: "1 day ago",
    appointment: "Scheduled",
  },
];

export const KPIS = [
  { label: "Total Leads", value: 1284, suffix: "", change: "+12.4%" },
  { label: "Hot Leads", value: 183, suffix: "", change: "+8.1%" },
  { label: "Appointments", value: 74, suffix: "", change: "+21.0%" },
  { label: "Conversion", value: 12.8, suffix: "%", change: "+1.6%" },
];

export const TREND = [38, 42, 40, 55, 60, 58, 66, 72, 70, 80, 86, 92];

export const SOURCES = [
  { label: "Website Audit", value: 420 },
  { label: "Google Search", value: 310 },
  { label: "Referral", value: 245 },
  { label: "Social", value: 180 },
  { label: "Maps", value: 129 },
];
