import { Link } from "react-router-dom";
import { Container } from "../ui";

const columns = [
  {
    title: "Product",
    links: ["Website Audit", "Business Score", "Lead Management", "Follow-Up", "Dashboard"],
  },
  {
    title: "Company",
    links: ["About", "Careers", "Partners", "Contact"],
  },
  {
    title: "Resources",
    links: ["Case Studies", "Guides", "Help Center", "Status"],
  },
  {
    title: "Legal",
    links: ["Privacy Policy", "Terms of Service", "Security"],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-white/[0.08] bg-ink">
      <Container className="py-16 md:py-20">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-[1.4fr_repeat(4,1fr)]">
          <div className="max-w-xs">
            <Link
              to="/"
              className="text-2xl font-extrabold tracking-tight text-white"
            >
              VENIC<span className="text-lime">X</span>
            </Link>
            <p className="mt-4 text-sm leading-relaxed text-muted">
              The growth platform that analyzes, scores, and converts your
              online presence into booked business.
            </p>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-2">
                {col.title}
              </h4>
              <ul className="mt-5 space-y-3.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm text-muted transition-colors hover:text-white"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-white/[0.08] pt-8 text-xs text-muted-2 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} VENICX. All rights reserved.</p>
          <p>Built for businesses that want to be found, chosen, and booked.</p>
        </div>
      </Container>
    </footer>
  );
}
