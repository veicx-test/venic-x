import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { Container, LinkButton } from "../ui";
import { cn } from "../../utils/cn";

const NAV_LINKS = [
  { label: "Product", href: "#product" },
  { label: "How It Works", href: "#process" },
  { label: "Results", href: "#results" },
  { label: "Pricing", href: "#pricing" },
  { label: "FAQ", href: "#faq" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  const handleNavClick = (href: string) => {
    setOpen(false);
    if (location.pathname !== "/") {
      navigate("/");
      window.setTimeout(() => {
        document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
      }, 60);
    } else {
      document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-white/[0.08] bg-ink/85 backdrop-blur-md"
          : "border-b border-transparent bg-transparent"
      )}
    >
      <Container className="flex h-16 items-center justify-between md:h-20">
        <Link
          to="/"
          className="flex items-center gap-2 text-xl font-extrabold tracking-tight text-white"
        >
          VENIC<span className="text-lime">X</span>
        </Link>

        <nav className="hidden items-center gap-9 lg:flex">
          {NAV_LINKS.map((link) => (
            <button
              key={link.label}
              onClick={() => handleNavClick(link.href)}
              className="text-[14px] font-medium text-muted transition-colors hover:text-white"
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Link
            to="/dashboard"
            className="text-[14px] font-medium text-muted transition-colors hover:text-white"
          >
            Client Login
          </Link>
          <LinkButton
            href="#analyze"
            size="sm"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick("#analyze");
            }}
          >
            Get Started
          </LinkButton>
        </div>

        <button
          className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 text-white lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
          aria-expanded={open}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </Container>

      {/* Mobile menu */}
      <div
        className={cn(
          "fixed inset-x-0 top-16 bottom-0 z-40 flex flex-col bg-ink transition-all duration-300 lg:hidden",
          open
            ? "pointer-events-auto translate-x-0 opacity-100"
            : "pointer-events-none translate-x-4 opacity-0"
        )}
      >
        <div className="flex flex-1 flex-col justify-between overflow-y-auto container-px py-8">
          <nav className="flex flex-col gap-1">
            {NAV_LINKS.map((link, i) => (
              <button
                key={link.label}
                onClick={() => handleNavClick(link.href)}
                className="flex min-h-[56px] items-center border-b border-white/[0.06] text-left text-2xl font-semibold tracking-tight text-white"
                style={{ transitionDelay: `${i * 40}ms` }}
              >
                {link.label}
              </button>
            ))}
          </nav>

          <div className="flex flex-col gap-3 pt-8">
            <Link
              to="/dashboard"
              className="flex h-14 items-center justify-center rounded-full border border-white/15 text-base font-semibold text-white"
            >
              Client Login
            </Link>
            <LinkButton
              href="#analyze"
              size="lg"
              className="w-full"
              onClick={(e) => {
                e.preventDefault();
                handleNavClick("#analyze");
              }}
            >
              Get Started
            </LinkButton>
          </div>
        </div>
      </div>
    </header>
  );
}
