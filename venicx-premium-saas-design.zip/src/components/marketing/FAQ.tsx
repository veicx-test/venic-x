import { useState } from "react";
import { Plus } from "lucide-react";
import { Container, Eyebrow, Reveal } from "../ui";
import { cn } from "../../utils/cn";

const FAQS = [
  {
    q: "How does the free audit work?",
    a: "Enter your website address and VENICX scans your public online presence — your website, search visibility, and business listings — to generate your Business Readiness Score in under a minute.",
  },
  {
    q: "Do I need any technical knowledge to use VENICX?",
    a: "No. VENICX is built for business owners, not developers. Everything from your audit to your dashboard is presented in plain business language.",
  },
  {
    q: "How does lead follow-up work?",
    a: "Once a lead comes in, VENICX automatically scores it and prepares the right follow-up at the right time, so no enquiry is left waiting.",
  },
  {
    q: "Can I see all my leads and appointments in one place?",
    a: "Yes. Your dashboard gives you a single, clear view of every lead, its status, and any upcoming appointments — accessible from any device.",
  },
  {
    q: "Is my business data secure?",
    a: "Yes. All data is processed and stored securely on our backend systems. Your information is never exposed in the browser or shared with third parties without consent.",
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="border-t border-white/[0.08] py-20 md:py-28">
      <Container className="max-w-4xl">
        <Reveal>
          <Eyebrow>FAQ</Eyebrow>
          <h2 className="mt-5 text-balance text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">
            Questions, answered.
          </h2>
        </Reveal>

        <div className="mt-12 divide-y divide-white/[0.08] border-t border-white/[0.08] md:mt-16">
          {FAQS.map((item, i) => {
            const isOpen = openIndex === i;
            return (
              <div key={item.q}>
                <button
                  onClick={() => setOpenIndex(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-6 py-6 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="text-base font-semibold text-white sm:text-lg">
                    {item.q}
                  </span>
                  <Plus
                    className={cn(
                      "h-5 w-5 shrink-0 text-lime transition-transform duration-300",
                      isOpen && "rotate-45"
                    )}
                  />
                </button>
                <div
                  className={cn(
                    "grid overflow-hidden transition-all duration-300 ease-out",
                    isOpen
                      ? "grid-rows-[1fr] opacity-100 pb-6"
                      : "grid-rows-[0fr] opacity-0"
                  )}
                >
                  <p className="overflow-hidden text-sm leading-relaxed text-muted sm:text-[15px]">
                    {item.a}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
