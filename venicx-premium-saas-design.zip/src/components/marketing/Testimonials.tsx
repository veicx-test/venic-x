import { Container, Eyebrow, Reveal } from "../ui";

const TESTIMONIALS = [
  {
    quote:
      "We went from missing calls after hours to booking three extra jobs a week. VENICX just handles the follow-up we never had time for.",
    name: "Michael Naidoo",
    role: "Owner, Naidoo Plumbing & Maintenance",
  },
  {
    quote:
      "The readiness score showed us exactly what was hurting our bookings. Fixed the top three issues and enquiries doubled in six weeks.",
    name: "Lerato Mokoena",
    role: "Practice Manager, Bright Smile Dental",
  },
  {
    quote:
      "Our leads used to sit in a spreadsheet. Now every enquiry is scored and followed up automatically — our team finally focuses on selling.",
    name: "James van der Merwe",
    role: "Director, Coastal Realty Group",
  },
];

const STATS = [
  { value: "2,400+", label: "Audits completed" },
  { value: "18K+", label: "Leads scored" },
  { value: "37%", label: "Avg. lift in booked calls" },
  { value: "4.9/5", label: "Average client rating" },
];

export function Testimonials() {
  return (
    <section id="results" className="border-t border-white/[0.08] py-20 md:py-28">
      <Container>
        <Reveal className="max-w-2xl">
          <Eyebrow>RESULTS</Eyebrow>
          <h2 className="mt-5 text-balance text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">
            Businesses that got found — and got booked.
          </h2>
        </Reveal>

        <div className="mt-12 grid grid-cols-2 gap-6 border-y border-white/[0.08] py-10 md:mt-16 md:grid-cols-4 md:gap-4">
          {STATS.map((stat, i) => (
            <Reveal key={stat.label} delay={i * 60}>
              <p className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
                {stat.value}
              </p>
              <p className="mt-1.5 text-xs uppercase tracking-[0.15em] text-muted-2">
                {stat.label}
              </p>
            </Reveal>
          ))}
        </div>

        <div className="mt-14 grid grid-cols-1 gap-4 md:mt-16 md:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 80}>
              <div className="flex h-full flex-col justify-between rounded-2xl border border-white/[0.08] bg-surface/50 p-7">
                <p className="text-[15px] leading-relaxed text-white/90">
                  “{t.quote}”
                </p>
                <div className="mt-8">
                  <p className="text-sm font-semibold text-white">{t.name}</p>
                  <p className="text-xs text-muted-2">{t.role}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
