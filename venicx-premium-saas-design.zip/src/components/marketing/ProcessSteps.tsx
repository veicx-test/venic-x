import { Container, Eyebrow, Reveal } from "../ui";

const STEPS = [
  {
    number: "01",
    title: "Analyze",
    description:
      "We scan your website, Google Business Profile, and online visibility in seconds — no technical setup required.",
  },
  {
    number: "02",
    title: "Score",
    description:
      "Get a clear Business Readiness Score with the exact opportunities holding your business back from more customers.",
  },
  {
    number: "03",
    title: "Improve",
    description:
      "We help you close the visibility gaps that matter most, so new visitors can actually find and trust you.",
  },
  {
    number: "04",
    title: "Convert",
    description:
      "Every lead is scored, followed up, and guided to book — automatically, around the clock.",
  },
];

export function ProcessSteps() {
  return (
    <section id="process" className="border-t border-white/[0.08] py-20 md:py-28">
      <Container>
        <Reveal>
          <Eyebrow>HOW IT WORKS</Eyebrow>
          <h2 className="mt-5 max-w-2xl text-balance text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">
            From unknown to booked, in four steps.
          </h2>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-0 md:mt-20 md:grid-cols-4">
          {STEPS.map((step, i) => (
            <Reveal key={step.number} delay={i * 90}>
              <div
                className={`h-full border-t border-white/[0.08] py-8 pr-6 md:border-t-0 md:border-l md:py-2 ${
                  i === 0 ? "md:pl-0" : "md:pl-8"
                }`}
              >
                <span className="font-mono text-sm font-semibold text-muted-2">
                  {step.number} /
                </span>
                <h3 className="mt-4 text-2xl font-bold tracking-tight text-white">
                  {step.title}
                </h3>
                <p className="mt-3 text-[15px] leading-relaxed text-muted">
                  {step.description}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
