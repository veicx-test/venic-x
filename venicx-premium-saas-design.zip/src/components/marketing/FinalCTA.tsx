import { useState } from "react";
import { Button, Container } from "../ui";

export function FinalCTA() {
  const [url, setUrl] = useState("");

  return (
    <section className="border-t border-white/[0.08] py-20 md:py-28">
      <Container>
        <div className="relative overflow-hidden rounded-3xl border border-white/[0.1] bg-surface px-6 py-14 text-center sm:px-12 md:py-20">
          <div className="pointer-events-none absolute -top-24 left-1/2 h-64 w-[520px] -translate-x-1/2 rounded-full bg-lime/[0.08] blur-[100px]" />
          <div className="relative">
            <h2 className="mx-auto max-w-2xl text-balance text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">
              Ready to see what's possible for your business?
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-balance text-base text-muted sm:text-lg">
              Run your free audit now and get your Business Readiness Score
              in under a minute.
            </p>

            <form
              className="mx-auto mt-9 flex max-w-md flex-col gap-3 sm:flex-row"
              onSubmit={(e) => {
                e.preventDefault();
                document
                  .querySelector("#analyze")
                  ?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              <input
                type="text"
                placeholder="example.co.za"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="h-14 flex-1 rounded-full border border-white/15 bg-white/[0.04] px-6 text-[15px] text-white placeholder:text-muted-2 focus:border-lime/60"
              />
              <Button type="submit" size="lg" className="sm:w-auto">
                Analyze My Business
              </Button>
            </form>

            <p className="mt-5 text-xs uppercase tracking-[0.15em] text-muted-2">
              No credit card required &middot; Results in under 60 seconds
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
}
