import { FormEvent, useState } from "react";
import { ArrowRight, CheckCircle2, Loader2, Sparkles } from "lucide-react";
import { Button, Container, Eyebrow, ScoreGauge } from "../ui";
import { cn } from "../../utils/cn";

type Stage = "idle" | "loading" | "error" | "done";

const LOADING_STEPS = [
  "Scanning your website...",
  "Checking your online visibility...",
  "Calculating your business score...",
];

function normalizeUrl(input: string) {
  const trimmed = input.trim();
  if (!trimmed) return "";
  return trimmed.replace(/^https?:\/\//, "").replace(/\/$/, "");
}

function isPlausibleDomain(value: string) {
  return /^[a-z0-9-]+(\.[a-z0-9-]+)+$/i.test(value);
}

export function Hero() {
  const [url, setUrl] = useState("");
  const [stage, setStage] = useState<Stage>("idle");
  const [stepIndex, setStepIndex] = useState(0);
  const [error, setError] = useState("");
  const [score, setScore] = useState(0);

  const runAnalysis = (e: FormEvent) => {
    e.preventDefault();
    const domain = normalizeUrl(url);

    if (!domain || !isPlausibleDomain(domain)) {
      setError("Please enter a valid website address, e.g. example.co.za");
      setStage("error");
      return;
    }

    setError("");
    setStage("loading");
    setStepIndex(0);

    let step = 0;
    const interval = window.setInterval(() => {
      step += 1;
      if (step < LOADING_STEPS.length) {
        setStepIndex(step);
      }
    }, 750);

    window.setTimeout(() => {
      window.clearInterval(interval);
      const seed = domain
        .split("")
        .reduce((acc, char) => acc + char.charCodeAt(0), 0);
      const generatedScore = 42 + (seed % 46);
      setScore(generatedScore);
      setStage("done");
    }, 750 * LOADING_STEPS.length + 400);
  };

  const reset = () => {
    setStage("idle");
    setUrl("");
    setError("");
  };

  return (
    <section
      id="analyze"
      className="relative overflow-hidden pt-32 pb-20 md:pt-44 md:pb-28"
    >
      <div className="pointer-events-none absolute inset-0 noise-overlay opacity-[0.15]" />
      <div className="pointer-events-none absolute -top-32 right-[-10%] h-[420px] w-[420px] rounded-full bg-lime/[0.06] blur-[110px]" />

      <Container className="relative">
        <div className="max-w-3xl">
          <Eyebrow>VENICX / BUSINESS GROWTH PLATFORM</Eyebrow>

          <h1 className="mt-6 text-balance text-[2.5rem] font-extrabold leading-[1.05] tracking-tight text-white sm:text-6xl md:text-7xl">
            Your business, found.
            <br />
            Your leads, <span className="text-lime">converted.</span>
          </h1>

          <p className="mt-6 max-w-xl text-balance text-base leading-relaxed text-muted sm:text-lg">
            VENICX analyzes your online presence, scores your business
            readiness, and turns every visitor into a booked appointment —
            automatically.
          </p>
        </div>

        {/* Analyzer card */}
        <div className="mt-10 max-w-2xl md:mt-14">
          <div className="rounded-2xl border border-white/[0.1] bg-surface/70 p-2 shadow-2xl shadow-black/40 backdrop-blur">
            {stage !== "done" ? (
              <form
                onSubmit={runAnalysis}
                className="flex flex-col gap-2 sm:flex-row sm:items-center"
              >
                <div className="flex-1 px-4 pt-3 sm:pt-0">
                  <label
                    htmlFor="website"
                    className="block text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-2"
                  >
                    Enter your website
                  </label>
                  <input
                    id="website"
                    type="text"
                    inputMode="url"
                    autoComplete="off"
                    placeholder="example.co.za"
                    value={url}
                    onChange={(ev) => {
                      setUrl(ev.target.value);
                      if (stage === "error") setStage("idle");
                    }}
                    disabled={stage === "loading"}
                    className="mt-1 h-9 w-full bg-transparent text-lg font-medium text-white placeholder:text-muted-2/70 focus:outline-none disabled:opacity-60"
                  />
                </div>
                <Button
                  type="submit"
                  size="lg"
                  disabled={stage === "loading"}
                  className="m-2 shrink-0 sm:m-0 sm:mr-2"
                >
                  {stage === "loading" ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Analyzing
                    </span>
                  ) : (
                    "Run Free Audit"
                  )}
                </Button>
              </form>
            ) : (
              <div className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-2 text-sm font-medium text-white">
                  <CheckCircle2 className="h-4 w-4 text-lime" />
                  Report ready for{" "}
                  <span className="text-muted">{normalizeUrl(url)}</span>
                </div>
                <button
                  onClick={reset}
                  className="text-sm font-semibold text-lime underline-offset-4 hover:underline"
                >
                  Analyze another site
                </button>
              </div>
            )}
          </div>

          {stage === "error" && (
            <p className="mt-3 px-1 text-sm font-medium text-rose-400">
              {error}
            </p>
          )}

          {stage === "loading" && (
            <div className="mt-4 flex items-center gap-2 px-1 text-sm text-muted">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-lime opacity-60" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-lime" />
              </span>
              {LOADING_STEPS[stepIndex]}
            </div>
          )}

          {stage === "done" && (
            <div
              className={cn(
                "mt-4 grid grid-cols-1 gap-6 rounded-2xl border border-white/[0.1] bg-surface/50 p-6 sm:grid-cols-[auto_1fr] sm:items-center md:p-8"
              )}
            >
              <ScoreGauge score={score} />
              <div>
                <Eyebrow className="text-white/50">
                  BUSINESS READINESS SCORE
                </Eyebrow>
                <p className="mt-2 text-2xl font-bold text-white">
                  {score >= 75
                    ? "Strong foundation"
                    : score >= 55
                    ? "Good, with room to grow"
                    : "Significant opportunity"}
                </p>
                <p className="mt-2 flex items-center gap-2 text-sm text-muted">
                  <Sparkles className="h-4 w-4 text-lime" />
                  We've identified{" "}
                  {Math.max(2, Math.round((100 - score) / 12))} opportunities
                  to improve your visibility.
                </p>
                <Button size="sm" className="mt-5">
                  Get My Full Report
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Trust row */}
        <div className="mt-14 flex flex-wrap items-center gap-x-10 gap-y-4 border-t border-white/[0.08] pt-8 text-xs uppercase tracking-[0.18em] text-muted-2 md:mt-20">
          <span>Trusted by growing businesses</span>
          <span className="hidden h-3 w-px bg-white/10 sm:block" />
          <span className="flex items-center gap-1 text-white/70">
            <ArrowRight className="h-3 w-3 rotate-90 text-lime" />
            2,400+ audits run
          </span>
          <span className="flex items-center gap-1 text-white/70">
            <ArrowRight className="h-3 w-3 rotate-90 text-lime" />
            18,000+ leads scored
          </span>
        </div>
      </Container>
    </section>
  );
}
