import {
  BadgeCheck,
  CalendarCheck2,
  Gauge,
  LayoutDashboard,
  MessageSquareText,
  Radar,
} from "lucide-react";
import { Card, Container, Eyebrow, Reveal } from "../ui";

const FEATURES = [
  {
    icon: Radar,
    title: "Instant visibility audit",
    description:
      "See exactly how your business shows up online — website, search, maps, and reviews — in one clear snapshot.",
  },
  {
    icon: Gauge,
    title: "Business Readiness Score",
    description:
      "A single, honest score that tells you how ready your business is to win new customers, with clear priorities.",
  },
  {
    icon: BadgeCheck,
    title: "Automatic lead scoring",
    description:
      "Every enquiry is instantly ranked Hot, Warm, or Cold, so your team always knows who to speak to first.",
  },
  {
    icon: MessageSquareText,
    title: "Smart follow-up",
    description:
      "Your leads are followed up at the right moment, in the right tone, without anyone lifting a finger.",
  },
  {
    icon: CalendarCheck2,
    title: "Appointment booking",
    description:
      "Qualified leads are guided straight into your calendar — reducing no-shows and manual back-and-forth.",
  },
  {
    icon: LayoutDashboard,
    title: "One clear dashboard",
    description:
      "Track leads, appointments, and performance in a single, simple view built for busy business owners.",
  },
];

export function Features() {
  return (
    <section id="product" className="border-t border-white/[0.08] py-20 md:py-28">
      <Container>
        <Reveal className="max-w-2xl">
          <Eyebrow>THE PLATFORM</Eyebrow>
          <h2 className="mt-5 text-balance text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">
            Everything your business needs to grow, minus the guesswork.
          </h2>
          <p className="mt-5 text-balance text-base leading-relaxed text-muted sm:text-lg">
            VENICX replaces scattered tools and manual follow-up with one
            connected system that works for you in the background.
          </p>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 md:mt-20 lg:grid-cols-3">
          {FEATURES.map((feature, i) => (
            <Reveal key={feature.title} delay={i * 70}>
              <Card className="h-full transition-colors duration-300 hover:border-white/20">
                <feature.icon
                  className="h-6 w-6 text-lime"
                  strokeWidth={1.75}
                />
                <h3 className="mt-6 text-lg font-bold tracking-tight text-white">
                  {feature.title}
                </h3>
                <p className="mt-3 text-[14.5px] leading-relaxed text-muted">
                  {feature.description}
                </p>
              </Card>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
