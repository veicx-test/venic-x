import { Check } from "lucide-react";
import { Button, Container, Eyebrow, Reveal } from "../ui";
import { cn } from "../../utils/cn";

const PLANS = [
  {
    name: "Starter",
    price: "R1,499",
    period: "/mo",
    description: "For small businesses ready to stop missing leads.",
    features: [
      "Website & visibility audit",
      "Business Readiness Score",
      "Lead capture & scoring",
      "Email support",
    ],
    highlighted: false,
  },
  {
    name: "Growth",
    price: "R3,299",
    period: "/mo",
    description: "For businesses ready to automate follow-up and booking.",
    features: [
      "Everything in Starter",
      "Automatic lead follow-up",
      "Appointment booking",
      "Priority support",
      "Monthly performance review",
    ],
    highlighted: true,
  },
  {
    name: "Scale",
    price: "Custom",
    period: "",
    description: "For multi-location or high-volume businesses.",
    features: [
      "Everything in Growth",
      "Multi-location dashboard",
      "Custom lead routing",
      "Dedicated success manager",
      "Advanced reporting",
    ],
    highlighted: false,
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="border-t border-white/[0.08] py-20 md:py-28">
      <Container>
        <Reveal className="max-w-2xl">
          <Eyebrow>PRICING</Eyebrow>
          <h2 className="mt-5 text-balance text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">
            Simple pricing. No hidden fees.
          </h2>
          <p className="mt-5 text-base leading-relaxed text-muted sm:text-lg">
            Every plan includes your full business audit and readiness score.
            Upgrade as your lead volume grows.
          </p>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-5 md:mt-16 lg:grid-cols-3">
          {PLANS.map((plan, i) => (
            <Reveal key={plan.name} delay={i * 90}>
              <div
                className={cn(
                  "flex h-full flex-col rounded-2xl border p-7 md:p-8",
                  plan.highlighted
                    ? "border-lime/40 bg-surface"
                    : "border-white/[0.08] bg-surface/40"
                )}
              >
                {plan.highlighted && (
                  <span className="mb-5 inline-flex w-fit items-center rounded-full bg-lime/15 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-lime">
                    Most popular
                  </span>
                )}
                <h3 className="text-xl font-bold tracking-tight text-white">
                  {plan.name}
                </h3>
                <p className="mt-2 text-sm text-muted">{plan.description}</p>
                <div className="mt-6 flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold tracking-tight text-white">
                    {plan.price}
                  </span>
                  <span className="text-sm text-muted-2">{plan.period}</span>
                </div>

                <ul className="mt-7 flex-1 space-y-3.5">
                  {plan.features.map((f) => (
                    <li
                      key={f}
                      className="flex items-start gap-2.5 text-sm text-white/85"
                    >
                      <Check
                        className="mt-0.5 h-4 w-4 shrink-0 text-lime"
                        strokeWidth={2.5}
                      />
                      {f}
                    </li>
                  ))}
                </ul>

                <Button
                  variant={plan.highlighted ? "primary" : "secondary"}
                  className="mt-8 w-full"
                >
                  {plan.price === "Custom" ? "Talk to Sales" : "Get Started"}
                </Button>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
