import { ButtonHTMLAttributes, AnchorHTMLAttributes, ReactNode } from "react";
import { ArrowRight } from "lucide-react";
import { cn } from "../utils/cn";
import { useInView, usePrefersReducedMotion } from "../lib/hooks";

/* ---------------------------------- Layout --------------------------------- */

export function Container({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={cn("mx-auto w-full max-w-[1360px] container-px", className)}>
      {children}
    </div>
  );
}

export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.15);
  const reduced = usePrefersReducedMotion();

  if (reduced) {
    return (
      <div ref={ref} className={className}>
        {children}
      </div>
    );
  }

  return (
    <div
      ref={ref}
      className={cn(className, inView ? "animate-fade-up" : "opacity-0")}
      style={{ animationDelay: inView ? `${delay}ms` : undefined }}
    >
      {children}
    </div>
  );
}

/* --------------------------------- Typography ------------------------------- */

export function Eyebrow({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-lime",
        className
      )}
    >
      {children}
    </span>
  );
}

/* ----------------------------------- Button --------------------------------- */

type ButtonBaseProps = {
  variant?: "primary" | "secondary" | "ghost";
  size?: "md" | "lg" | "sm";
  icon?: boolean;
  className?: string;
  children: ReactNode;
};

const buttonStyles = {
  base: "group relative inline-flex items-center justify-center gap-2 rounded-full font-semibold tracking-tight transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",
  variant: {
    primary:
      "bg-lime text-ink hover:bg-white active:scale-[0.98] shadow-[0_0_0_0_rgba(214,255,0,0)]",
    secondary:
      "bg-white/[0.04] text-white border border-white/15 hover:border-white/35 hover:bg-white/[0.08] active:scale-[0.98]",
    ghost:
      "text-white/80 hover:text-white",
  },
  size: {
    sm: "h-10 px-4 text-sm",
    md: "h-12 px-6 text-[15px]",
    lg: "h-14 px-8 text-base",
  },
};

export function Button({
  variant = "primary",
  size = "md",
  icon = true,
  className,
  children,
  ...props
}: ButtonBaseProps & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={cn(
        buttonStyles.base,
        buttonStyles.variant[variant],
        buttonStyles.size[size],
        className
      )}
      {...props}
    >
      <span>{children}</span>
      {icon && (
        <ArrowRight
          className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
          strokeWidth={2.5}
        />
      )}
    </button>
  );
}

export function LinkButton({
  variant = "primary",
  size = "md",
  icon = true,
  className,
  children,
  ...props
}: ButtonBaseProps & AnchorHTMLAttributes<HTMLAnchorElement>) {
  return (
    <a
      className={cn(
        buttonStyles.base,
        buttonStyles.variant[variant],
        buttonStyles.size[size],
        className
      )}
      {...props}
    >
      <span>{children}</span>
      {icon && (
        <ArrowRight
          className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
          strokeWidth={2.5}
        />
      )}
    </a>
  );
}

/* ----------------------------------- Badge ----------------------------------- */

export function StatusBadge({ status }: { status: "hot" | "warm" | "cold" }) {
  const config = {
    hot: {
      label: "HOT",
      icon: "●",
      classes: "bg-lime/15 text-lime border-lime/30",
    },
    warm: {
      label: "WARM",
      icon: "●",
      classes: "bg-amber-400/15 text-amber-300 border-amber-400/30",
    },
    cold: {
      label: "COLD",
      icon: "●",
      classes: "bg-sky-400/10 text-sky-300 border-sky-400/25",
    },
  }[status];

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider",
        config.classes
      )}
    >
      <span className="text-[8px]">{config.icon}</span>
      {config.label}
    </span>
  );
}

/* --------------------------------- Score Gauge -------------------------------- */

export function ScoreGauge({
  score,
  size = 168,
  animate = true,
}: {
  score: number;
  size?: number;
  animate?: boolean;
}) {
  const stroke = size * 0.07;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const reduced = usePrefersReducedMotion();
  const offset = animate
    ? circumference - (score / 100) * circumference
    : circumference;

  return (
    <div
      className="relative inline-flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#D6FF00"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{
            transition: reduced ? "none" : "stroke-dashoffset 1.4s cubic-bezier(0.16,1,0.3,1)",
          }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-4xl font-bold tracking-tight text-white">
          {score}
        </span>
        <span className="text-[11px] uppercase tracking-widest text-muted">
          / 100
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------ Card ------------------------------------ */

export function Card({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-white/[0.08] bg-surface/60 p-6 md:p-8",
        className
      )}
    >
      {children}
    </div>
  );
}
